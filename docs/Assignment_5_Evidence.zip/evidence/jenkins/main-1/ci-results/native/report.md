# IIoT detection evaluation

Tool version: 1.0.0. Task: binary attack versus normal.

Input: example.csv. SHA-256: `164d9ec299133195514ff54f3f55e5a72e87c4e5492eb0bdef38b66859cc6ea4`.

## Baseline local-demo-v1

| Group | n | TP | FP | TN | FN | Precision | Recall | F1 | FPR | Accuracy | p95 ms |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Overall | 12 | 4 | 2 | 4 | 2 | 0.6667 | 0.6667 | 0.6667 | 0.3333 | 0.6667 | 75.0000 |
| environment | 4 | 1 | 1 | 1 | 1 | 0.5000 | 0.5000 | 0.5000 | 0.5000 | 0.5000 | 75.0000 |
| lighting | 4 | 1 | 1 | 1 | 1 | 0.5000 | 0.5000 | 0.5000 | 0.5000 | 0.5000 | 35.0000 |
| pump | 4 | 2 | 0 | 2 | 0 | 1.0000 | 1.0000 | 1.0000 | 0.0000 | 1.0000 | 55.0000 |

## Candidate hybrid-demo-v1

Input: candidate.csv. SHA-256: `15daf99bea08c663d7b0402b1051ad1ae73c7a65459af75cde478ff7c8ba0dba`.

| Group | n | TP | FP | TN | FN | Precision | Recall | F1 | FPR | Accuracy | p95 ms |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Overall | 12 | 5 | 1 | 5 | 1 | 0.8333 | 0.8333 | 0.8333 | 0.1667 | 0.8333 | 77.0000 |
| environment | 4 | 1 | 1 | 1 | 1 | 0.5000 | 0.5000 | 0.5000 | 0.5000 | 0.5000 | 77.0000 |
| lighting | 4 | 2 | 0 | 2 | 0 | 1.0000 | 1.0000 | 1.0000 | 0.0000 | 1.0000 | 37.0000 |
| pump | 4 | 2 | 0 | 2 | 0 | 1.0000 | 1.0000 | 1.0000 | 0.0000 | 1.0000 | 57.0000 |

Deltas (candidate minus baseline): F1 0.1667, FPR -0.1667, accuracy 0.1667.

## Interpretation

Positive class is attack (1). F1 is binary attack-class F1, not macro-F1 across attack types.

N/A (JSON null) means a metric is undefined or latency measurements are absent. Zero-denominator ratios are never presented as a successful score.

p95 uses the nearest-rank method over supplied latency_ms values; these are not timings measured by this tool.

A comparison describes only the supplied observations. Synthetic demo scores do not establish the accuracy or latency of a deployed IDS, or statistical significance.
